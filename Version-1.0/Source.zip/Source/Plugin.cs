using HarmonyLib;
using Timberborn.ModManagerScene;

namespace Tobbert.MorePlatforms
{
    public class Plugin : IModStarter
    {
        public void StartMod(IModEnvironment modEnvironment)
        {
            new Harmony("tobbert.moreplatforms").PatchAll();
        }
    }
}
