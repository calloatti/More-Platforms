using System.Linq;
using Timberborn.BaseComponentSystem;
using Timberborn.BlockObjectModelSystem;
using Timberborn.BlockSystem;
using Timberborn.Buildings;
using Timberborn.Coordinates;
using UnityEngine;

namespace Tobbert.MorePlatforms
{
    public class DirectionalConnector : BaseComponent, IAwakableComponent, IModelUpdater, IPrePlacementChangeListener, IPostPlacementChangeListener, IFinishedStateListener
    {
        private readonly IBlockService _blockService;
        private readonly PreviewBlockService _previewBlockService;

        private BuildingModel _buildingModel;
        private BlockObject _blockObject;
        private Transform _modelRoot;

        private static readonly Direction2D[] Directions = { Direction2D.Up, Direction2D.Down, Direction2D.Right, Direction2D.Left };

        public DirectionalConnector(IBlockService blockService, PreviewBlockService previewBlockService)
        {
            _blockService = blockService;
            _previewBlockService = previewBlockService;
        }

        public void Awake()
        {
            _blockObject = GetComponent<BlockObject>();
            _buildingModel = GetComponent<BuildingModel>();
        }

        public void OnPrePlacementChanged()
        {
            UpdateNeighbors();
        }

        public void OnPostPlacementChanged()
        {
            UpdateNeighbors();
        }

        public void OnEnterFinishedState()
        {
        }

        public void OnExitFinishedState()
        {
        }

        public void UpdateModel()
        {
            if (!_blockObject.Positioned)
                return;

            var finishedModel = _buildingModel.FinishedModel;
            if (!finishedModel)
                return;

            _modelRoot = finishedModel.transform;

            var upOccupied = CoordinatesAreOccupied(Direction2D.Up);
            var downOccupied = CoordinatesAreOccupied(Direction2D.Down);
            var rightOccupied = CoordinatesAreOccupied(Direction2D.Right);
            var leftOccupied = CoordinatesAreOccupied(Direction2D.Left);

            SetChildActive("#Up", upOccupied);
            SetChildActive("#Down", downOccupied);
            SetChildActive("#Right", rightOccupied);
            SetChildActive("#Left", leftOccupied);
            SetChildActive("#BottomUpDown", upOccupied && downOccupied);
            SetChildActive("#BottomLeftRight", rightOccupied && leftOccupied);
        }

        private void SetChildActive(string name, bool active)
        {
            var child = _modelRoot.Find(name);
            if (child)
                child.gameObject.SetActive(active);
        }

        private void UpdateNeighbors()
        {
            if (!_blockObject.Positioned)
                return;

            foreach (var direction in Directions)
            {
                var coords = GetNeighborCoordinates(direction);
                if (coords.HasValue)
                    UpdateModelAt(coords.Value);
            }
        }

        private void UpdateModelAt(Vector3Int coordinates)
        {
            var controller = _blockService.GetFirstObjectWithComponentAt<BlockObjectModelController>(coordinates);
            controller?.UpdateModel();

            var previewController = _previewBlockService.GetFirstObjectWithComponentAt<BlockObjectModelController>(coordinates);
            previewController?.UpdateModel();
        }

        private bool CoordinatesAreOccupied(Direction2D direction)
        {
            var coords = GetNeighborCoordinates(direction);
            if (!coords.HasValue)
                return false;

            return _blockService.AnyObjectAt(coords.Value)
                   || _previewBlockService.GetPreviewsAt(coords.Value).Any();
        }

        private Vector3Int? GetNeighborCoordinates(Direction2D direction)
        {
            var occupied = _blockObject.PositionedBlocks.GetOccupiedCoordinates();
            if (!occupied.Any())
                return null;

            var origin = occupied.First();
            var transformed = _blockObject.Orientation.Transform(direction);
            return origin + transformed.ToOffset();
        }
    }
}
