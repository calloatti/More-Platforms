using Timberborn.BlueprintSystem;

namespace Tobbert.MorePlatforms
{
    public record DirectionalConnectorSpec : ComponentSpec;
}
