using Timberborn.BlueprintSystem;

namespace Tobbert.MorePlatforms
{
    public record OverhangingBuildingSpec : ComponentSpec;
}
