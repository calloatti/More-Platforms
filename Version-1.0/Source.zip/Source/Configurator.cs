using Bindito.Core;
using Timberborn.TemplateInstantiation;

namespace Tobbert.MorePlatforms
{
    [Context("Game")]
    public class MorePlatformsConfigurator : Configurator
    {
        protected override void Configure()
        {
            Bind<DirectionalConnector>().AsTransient();
            Bind<OverhangingBuilding>().AsTransient();
            MultiBind<TemplateModule>().ToProvider(ProvideTemplateModule).AsSingleton();
        }

        private static TemplateModule ProvideTemplateModule()
        {
            var builder = new TemplateModule.Builder();
            builder.AddDecorator<DirectionalConnectorSpec, DirectionalConnector>();
            builder.AddDecorator<OverhangingBuildingSpec, OverhangingBuilding>();
            return builder.Build();
        }
    }
}
