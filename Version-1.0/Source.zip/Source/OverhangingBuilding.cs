using Timberborn.BaseComponentSystem;

namespace Tobbert.MorePlatforms
{
    public class OverhangingBuilding : BaseComponent
    {
        public int BlockObjectBlockIndex;
    }
}
